# -*- coding: utf-8 -*-
"""
android page implements  class
"""
