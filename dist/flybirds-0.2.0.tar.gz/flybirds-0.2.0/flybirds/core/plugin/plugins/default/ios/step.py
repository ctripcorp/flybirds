# -*- coding: utf-8 -*-
"""
ios step implements class
"""

from flybirds.core.plugin.plugins.default.app_base_step import AppBaseStep

__open__ = ["Step"]


class Step(AppBaseStep):
    """IOS Step Class"""

    name = "ios_step"
