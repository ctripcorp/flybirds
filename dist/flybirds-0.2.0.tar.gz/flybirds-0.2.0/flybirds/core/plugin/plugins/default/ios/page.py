# -*- coding: utf-8 -*-
"""
ios page core api implement
"""
