# coding=utf-8
"""
main point
"""

import flybirds.cli.__main__ as cli_main


def main():
    """
    main point func
    """
    cli_main.app()


if __name__ == "__main__":
    main()
