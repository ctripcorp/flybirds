# -*- coding: utf-8 -*-
"""
Custom Step statement implementation module
"""


def custom_function():
    pass
