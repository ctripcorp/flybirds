# -*- coding: utf-8 -*-
"""
this class just a flag that help to find plugin
"""


class PluginProxy:  # pylint: disable=too-few-public-methods
    """
    just a flag
    """

    def __init__(self):
        pass
