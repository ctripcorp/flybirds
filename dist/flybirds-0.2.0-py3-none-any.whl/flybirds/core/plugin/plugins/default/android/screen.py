# -*- coding: utf-8 -*-
"""
android screen imp
"""
from flybirds.core.plugin.plugins.default.screen import BaseScreen

__open__ = ["Screen"]


class Screen(BaseScreen):
    """
    screen imp
    """
    name = "android_screen"

    # def screen_shot(self, path):
    #     screen.screen_shot(path)
    #
    # def screen_link_to_behave(self, scenario, step_index, tag=None):
    #     screen.screen_link_to_behave(scenario, step_index, tag)
