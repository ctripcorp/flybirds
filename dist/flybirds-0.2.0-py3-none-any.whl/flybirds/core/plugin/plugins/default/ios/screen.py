# -*- coding: utf-8 -*-
"""
ios screen imp
"""

__open__ = ["Screen"]

from flybirds.core.plugin.plugins.default.screen import BaseScreen


class Screen(BaseScreen):
    """
    screen imp
    """
    name = "ios_screen"

    # def screen_shot(self, path):
    #     screen.screen_shot(path)
    #
    # def screen_link_to_behave(self, scenario, step_index, tag=None):
    #     screen.screen_link_to_behave(scenario, step_index, tag)
